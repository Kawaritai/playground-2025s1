#### Week 5 (STAT6014, prepared by Lucy Hu)

# To save your R Script: File -> Save
# To Run your R Script: Select the code => Click the Run button Or Press Ctrl + Enter / For Mac: Command + Enter
# To make a comment: use # (pound sign) before each comment

#### To set up working directory & import data
setwd

#### Remove all the variables defined previously
rm(list = ls())

# ======================================================================================================

#### Question One

auscars <- read.csv("auscars.csv", header=T)    
head(auscars)                                       
attach(auscars)                             

# ==========================================================================================================

#### Q1 (b)


## Recap

# X = Weight, Y = L.100k
head(auscars)
# sample data
# n = 62
length(Weight)
# k = 1
# p=k+1=2
# SLR


## 1. Now fit the requested model using lm():
auscars.lm <- lm(L.100k ~ Weight)
auscars.lm$coefficients
# Formula?

## 2. b0=? b1=? SE(b0)=? SE(b1)=?
summary(auscars.lm)$coefficient


## 3. Plot (the limits on the y-axis ranges from 5 up to 20)
# Range of Y
min(L.100k)
max(L.100k)

# Plot (X,Y)
plot(Weight, L.100k, ylim=c(5,20), 
     xlab="Unladen weight (kgs)", 
     ylab="Fuel efficiency (Litres/100Km)", 
     main="NRMA Car Data 1991")
# ylim=c(5,20)?
# Formula?

# Regression line
auscars.lm$coefficients
abline(coef(auscars.lm))
# This is the same as
abline(auscars.lm$coefficients)
# Formula?

# ==========================================================================================================

#### Q1 (c)

## Hypothesis testing recap (SLR)

## Hypothesis for slope B1?

## Method 1: Individual hypothesis for (B1)
summary(auscars.lm)$coefficients
# cv
qt(0.975,length(L.100k)-length(auscars.lm$coef))
# p-value
summary(auscars.lm)$coefficients
2*(1-pt(11.548169,length(L.100k)-length(auscars.lm$coef)))


## Method 2: Overall hypothesis (anova)
anova(auscars.lm)
# cv
qf(0.95,1,length(L.100k)-length(auscars.lm$coef))
# p-value
anova(auscars.lm)
1-pf(133.36,1,length(L.100k)-length(auscars.lm$coef))

## T^2 = F
summary(auscars.lm)$coefficients
anova(auscars.lm)
11.548169^2



## Challenge: If change to "B1=0.03 or B1>0.03"?
summary(auscars.lm)$coefficients
# TS
ts_challenge<-(summary(auscars.lm)$coefficients[2,1]
               -0.03)/summary(auscars.lm)$coefficients[2,2]
ts_challenge
(0.007227456-0.03)/0.000625853
# cv
qt(0.95,length(L.100k)-length(auscars.lm$coef))
# p-value
1-pt(ts_challenge,length(L.100k)-length(auscars.lm$coef))

# ==========================================================================================================

#### Q1 (d)

## R^2 = ?

## Interpretation = ?

## 1. R^2 = SSR/(SSR+SSE) (ANOVA)
anova(auscars.lm)
180.031/(180.031+80.998)

## 2. From Summary:
summary(auscars.lm)
summary(auscars.lm)$r.squared

## 3. r^2=R^2 (SLR):
cor(Weight,L.100k)^2



## Challenge: given R^2 => sample covariance?
sqrt(summary(auscars.lm)$r.squared)*sqrt(var(Weight))*sqrt(var(L.100k))
1/(length(Weight)-1)*sum((Weight-mean(Weight))*(L.100k-mean(L.100k)))


# ==========================================================================================================

#### Q1 (e)

## 1. Calculate CI(B0)
## Generate b0 and SE(b0)
coef(auscars.lm)
b0 <- coef(auscars.lm)[1]
b0

summary(auscars.lm)$coefficients
SEb0 <- summary(auscars.lm)$coef[1,2]
SEb0

## The df for residual:
# n
length(L.100k)
# n-p
auscars.lm$df
auscars.lm$df.residual


## The Critical value:
qt(0.025,auscars.lm$df)
qt(0.975,auscars.lm$df)
  
## CI(B0)
summary(auscars.lm)$coefficients
c(b0 + qt(0.025,auscars.lm$df)*SEb0, 
  b0 + qt(0.975,auscars.lm$df)*SEb0)

## Hypothesis for B0
summary(auscars.lm)$coefficients

## 2. Interpretation (B0)
min(Weight)
max(Weight)

# ==========================================================================================================

#### Q1 (f)

## Define new Xi
newWeight <- 1800

## 1. 95%CI 
predict(auscars.lm, newdata=as.data.frame(cbind(Weight=newWeight)),
        interval="confidence")

## 2. 95%PI
predict(auscars.lm, newdata=as.data.frame(cbind(Weight=newWeight)), 
        interval="prediction")

## Interpretation

## PI>CI

## Diagram

# ==========================================================================================================

#### Q1 (g)

## 1. New Xis: Generate a sequence from min(Weight) to max(Weight), the increment level is by 10 
min(Weight)
max(Weight)
newWeight <- seq(min(Weight),max(Weight),10)
newWeight

## 2. Calculate the fitted value of Y and CI for EACH of the new Xi
auscars.cis <- predict(auscars.lm, 
                       newdata=as.data.frame(cbind(Weight=newWeight)),
                       interval="confidence")
head(auscars.cis)

## 3. For each new Xi, we obtain its LB and UB for CI, 
## we have many new Xis, each Xi has 1 LB and 1 UB
lines(newWeight, auscars.cis[,"lwr"], lty=2)
lines(newWeight, auscars.cis[,"upr"], lty=2)

## 4. Calculate the fitted value of Y and PI for EACH of the new Xi
auscars.pis <- predict(auscars.lm, 
                       newdata=as.data.frame(cbind(Weight=newWeight)),
                       interval="prediction")
head(auscars.pis)

## 5. For each new Xi, we obtain its LB and UB for PI
lines(newWeight, auscars.pis[,"lwr"], lty=3)
lines(newWeight, auscars.pis[,"upr"], lty=3)
# add title on the graph
legend(720,20,c("Estimated SLR model", "95% Confidence Intervals", "95% Prediction Intervals"), lty=1:3)

## 6. CI vs PI

# --------------------------------------------------------------------

#### Some coding issues for CI
rm(list = ls())

# n=50
y1<-rnorm(50,3,2)
x1<-rnorm(50,1,4)
x2<-rnorm(50,6,7)

# fit a SLR model
model1<-lm(y1~x1)

# fit a MLR model
model2<-lm(y1~x1+x2)

# CI for SLR
newx1 <- seq(1,100)
predict(model1, newdata=as.data.frame(cbind(x1=newx1)), interval="confidence")
predict(model1, data.frame(cbind(x1=newx1)), interval="confidence")
predict(model1, data.frame(x1=newx1), interval="confidence")
predict(model1, data.frame(x1=seq(1,100)), interval="confidence")
# Check for the first observation
model1$coefficients[1]+model1$coefficients[2]*newx1[1]

# This is NOT the same as:
predict(model1, data.frame(newx1), interval="confidence")
# This is ALSO NOT the same as:
predict(model1, newdata=newx1, interval="confidence")
predict(model1, newx1, interval="confidence")
predict(model1, x1=newx1, interval="confidence")
predict(model1, x1=cbind(x1=data.frame(newx1)), interval="confidence")
predict(model1, x1=data.frame(newx1), interval="confidence")

# Tips
# Should use "data.frame(name for X1 you defined in your MODEL = new data for x1)" (SLR)
# Or use "data.frame(cbind(name for X1= new  for x1, name for X2 = new data for X2))" (SLR/MLR)


# CI for MLR
newx1 <- seq(1,100)
newx2 <- seq(5,104)
predict(model2, newdata=as.data.frame(cbind(x1=newx1,x2=newx2)), interval="confidence")
predict(model2, newdata=data.frame(cbind(x1=newx1,x2=newx2)), interval="confidence")
# Check for the first observation
model2$coefficients[1]+model2$coefficients[2]*newx1[1]+model2$coefficients[3]*newx2[1]

# This is NOT the same as:
predict(model2, data.frame(cbind(newx1,newx2)), interval="confidence")


#======================================================================
#======================================================================
#### Week 6 (STAT6014, prepared by Lucy Hu)

#### Question Two

#### Remove all the variables defined previously
rm(list = ls())


#### Upload data
## Run install.packages(faraway) to install the faraway library
# install.packages("faraway")
# library(faraway)

## Or you could read in the data from the Oracle:
prostate <- read.csv("prostate.csv", header=T)
head(prostate)
attach(prostate)

## Recap
# X = psa, Y = cavol
# ln(X) = lpsa, ln(Y) = lcavol
head(prostate)
# sample data
# n = 97
length(lpsa)
# k = 1
# p=k+1=2
# SLR

ln_x<-lpsa
ln_y<-lcavol

# ==========================================================================================================

#### Q2 (a)

## 1. Scatterplot
plot(ln_y,ln_x, 
     main="Relationship between prostate specific antigen test\n and cancer tumour volume", 
     xlab="log(Cancer Volume)", ylab="log(PSA)")
# Formula?
# Each observation: ln(Y) = B0+B1*ln(X)+Error_i

## 2. Correlation test
cor.test(ln_y, ln_x)

## TS
cor.test(ln_y, ln_x)$statistic

## TS by hand
samplecov<-sum((ln_y-mean(ln_y))* (ln_x-mean(ln_x))) /(length(ln_y)-1) # Sxy/(n-1)
samplevarx<-sum((ln_x-mean(ln_x))^2)/(length(ln_x)-1) # Sxx/(n-1)
samplevary<-sum((ln_y-mean(ln_y))^2)/(length(ln_y)-1) # Syy/(n-1)
samplecorr<- samplecov/ sqrt(samplevarx * samplevary) #rxy
samplecorr * sqrt((length(ln_y)-2)/(1-samplecorr^2))

cor.test(ln_y, ln_x)

## Given R^2 => TS=?

## CV
qt(0.975, length(ln_y)-2)
## p-value
cor.test(ln_y, ln_x)$p.value
2*(1-pt(10.54832,length(ln_y)-2))

# ==========================================================================================================

#### Q2 (b)

## 1. Fit a SLR for ln_y(ln(Y)), ln_x (ln(X)).
prostate.lm <- lm(ln_y ~ ln_x)
prostate.lm$coefficients
# Sample trend line: ln(Y) hat = -0.5 + 0.7499*ln(X) 

## 2. Residual plots
par(mfrow=c(2, 2))

## Residual plots/ Outlier
plot(prostate.lm, which=1) # Residual versus fitted
plot(prostate.lm, which=2) # Normality plot

## Influential 
plot(prostate.lm, which=4) # Cooks Distance (mix effect)
head(cooks.distance(prostate.lm))

## High leverage
barplot(hat(ln_x), main="Leverage plot of the hat values") # Leverage (influential point)
head(hat(ln_x))
abline(h=4/length(ln_x))  # Rule of Thumb: hi>2*p/n=2*2/n (in SLR), p=# parameters


# ==========================================================================================================

#### Q2 (c)

## Is there a significant relationship between ln(X) and ln(Y)?

## Overall hypothesis (Q2(c))
anova(prostate.lm)
qf(0.95,1,length(ln_y)-length(prostate.lm$coef))

## Individual hypothesis (Q2(d))
summary(prostate.lm)$coefficients

## Correlation test (Q2(a))
cor.test(ln_y, ln_x)

## Consistent conclusions!

# ==========================================================================================================

#### Q2 (d)

## 1. b0=? b1=? SE(b0)=? SE(b1)=? 
##    Hypothesis(B0,B1)=?
summary(prostate.lm)$coefficients
qt(0.975,length(ln_y)-length(prostate.lm$coef))

## 2. log transformation for (b0)
prostate.lm$coef
exp(prostate.lm$coef)

# ==========================================================================================================

#### Q2 (e)

par(mfrow=c(1, 1))

## 1. Generate a seqence of Xis
# check the domain for ln_x (ln(X))
range(ln_x)  
# generate a sequence follows that domain (from -20/20=-1 to 120/20=6, the incremental unit is 1/20)
ln_x.values <- -20:120/20
ln_x.values

## 2. 95% CI for the mean or expected value of ln_y
cintervals <- predict(prostate.lm, newdata=data.frame(ln_x=ln_x.values), interval="confidence")
cintervals[1,]

## 3. Plot log(psa) versus log(cavol)
plot(ln_x, ln_y, main="Relationship between cancer tumour volume\n and prostate specific antigen test", xlab="log(X)", ylab="log(Y)")
# Generate the fitted line: ln_y hat = b0 + b1 * ln_x
abline(prostate.lm$coef)
# Generate the CI's UB and LB each (from 141# of Xis => we have 141# of UB and LB each)
lines(ln_x.values, cintervals[,"lwr"], lty=2)
lines(ln_x.values, cintervals[,"upr"], lty=2)
legend(-0.63, 4, c("SLR Model", "95% Confidence Intervals"), lty=1:2)

## 5. PI for 141# of new Xis
pintervals <- predict(prostate.lm, newdata=data.frame(ln_x=ln_x.values), interval="prediction")
pintervals[1,]
lines(ln_x.values, pintervals[,"lwr"], lty=3)
lines(ln_x.values, pintervals[,"upr"], lty=3)

## 6. Transformation
# Scatterplot: pas versus cavol
plot(exp(ln_x), exp(ln_y), main="Relationship between cancer tumour volume\n and prostate specific antigen test", xlab="X (ng/ml)", ylab="Y (ml)")
# Generate the fitted line, CI, PI based on Xi = psa (not ln_x) (based on exp of 141# of ln_x)
lines(exp(ln_x.values), exp(cintervals[,"fit"]))
lines(exp(ln_x.values), exp(cintervals[,"lwr"]), lty=2)
lines(exp(ln_x.values), exp(cintervals[,"upr"]), lty=2)
lines(exp(ln_x.values), exp(pintervals[,"lwr"]), lty=3)
lines(exp(ln_x.values), exp(pintervals[,"upr"]), lty=3)
legend(164, 10, c("SLR Model on log-log scale", "95% Confidence Intervals", "95% Prediction Intervals"), lty=1:3)

# -------------------------------------------------

#### Admin issues

#### Identify an unusual observation
x1<-c(1,2,3,4,5)
y1<-c(4,6,2,3,40)

plot(x1,y1)
# Click on the plot + press "ESC" to escape + Obtain the observation order
identify(x1,y1)
