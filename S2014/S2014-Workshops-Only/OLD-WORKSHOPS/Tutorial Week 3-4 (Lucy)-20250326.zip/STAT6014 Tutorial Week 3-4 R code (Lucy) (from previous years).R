#### Week 3 (STAT6014, prepared by Lucy Hu)

# (for students attended Monday class - we will cover this topic in Week 4)

# To save your R Script: File -> Save
# To Run your R Script: Select the code => Click the Run button Or Press Ctrl + Enter / For Mac: Command + Enter
# To make a comment: use # (pound sign) before each comment

#### To set up working directory & import data
setwd

# ======================================================================================================

#### Question One
Lubricant <- read.csv("Lubricant.csv", header=TRUE)
Lubricant                             

viscos                                 
Lubricant$viscos

attach(Lubricant)                               
viscos

# ==========================================================================================================

#### Q1 (a)

## 0. Regression revision


## Define
# X = pressure
# Y = viscos
head(Lubricant)
# n=53
length(viscos)
# k=#slope=1 (B1)
# p=#parameters=k+1=2 (B0,B1)

# Sample or population data?


## Hypothesis testing (SLR)
# Individual
# Correlation
# Overall


## 1. Now fit the requested model using lm() and 
Lubricant.lm <- lm(viscos ~ pressure)
Lubricant.lm
# equation?


## 2. b0=? b1=? SE(b0)=? SE(b1)=?
summary(Lubricant.lm)
summary(Lubricant.lm)$coefficients
# OLSE => b0, b1
# e-05=*10^(-5)


## 3. Sxx=?
Sxx <- sum((pressure - mean(pressure))^2)
Sxx

# Challenge1: Use V(x) => Sxx=?
var(pressure)
length(pressure)-1
var(pressure)*(length(pressure)-1)

# Challenge2: Sxx => V(X)=?
Sxx/(length(pressure)-1)
var(pressure)


## 4. SSE=?
anova(Lubricant.lm)      
SSerror <- sum(residuals(Lubricant.lm)^2)
SSerror      


## 3 & 4. MSE=?
anova(Lubricant.lm)   

# n-p
length(pressure)
length(viscos)
length(Lubricant.lm$coef)

MSerror <- SSerror/(length(viscos)-length(Lubricant.lm$coef))
MSerror


## Hypothesis testing - recap

## 5. Individual Hypothesis for B1: 
# SE
summary(Lubricant.lm)$coefficients
sqrt(MSerror/Sxx)  

## Hypothesis for B1
# TS
summary(Lubricant.lm)$coefficients
Lubricant.lm$coefficients
(Lubricant.lm$coefficients[2]-0)/(sqrt(MSerror/Sxx))
# P-value
summary(Lubricant.lm)$coef
# n-p
length(viscos)
length(Lubricant.lm$coef)
# CV
qt(0.975,length(viscos)-2)

# ==========================================================================================================
# ==========================================================================================================
# ==========================================================================================================
# ==========================================================================================================

#### Week 4 (STAT6014, prepared by Lucy Hu)

#### Recap
# X = pressure
# Y=viscos
head(Lubricant)
# sample data
# n = 53
length(viscos)
# k = 1, p=k+1=2
Lubricant.lm$coef
length(Lubricant.lm$coef)



# ==========================================================================================================


#### Q1 (b)

## Recall 3 equations
  
## 1. Plots vs fitted line
plot(pressure, viscos, xlab="Pressure", 
     ylab="Viscosity", main="Lubricant data")

Lubricant.lm$coef
abline(Lubricant.lm$coefficients)  

## 2. Yhat=? when Xi=1000 and 10000
Lubricant.lm$coef
# b0+b1*1000=?
c(1, 1000) %*% Lubricant.lm$coef
# b0+b1*10000=?
t(Lubricant.lm$coef) %*% c(1, 10000)

## Check domain
min(pressure)
max(pressure)

# ==========================================================================================================
  
#### Q1 (c) 
  
# xbar=? ybar=? 
# Does (xbar, ybar) lie on the regression line?
xbar <- mean(pressure)
ybar <- mean(viscos)

c(xbar, ybar)

# b0+b1*xbar=?
t(Lubricant.lm$coef) %*% c(1, xbar)
ybar


# ==========================================================================================================

#### Hypothesis testing (SLR)
# (1). individual hypothesis (B0,B1)
#     -> t -> summary -> Q1(a)
# (2). overall hypothesis (Slopes) 
#     -> F -> ANOVA -> Q1(d)
# (3). Correlation "Rho" -> t


# ==========================================================================================================

#### Q1 (d)

# 1. Use ANOVA table (overall hypothesis)
anova(Lubricant.lm)

# SSE= ? MSE= ?
SSerror
MSerror

# Residual degrees of freedom? n-p
Lubricant.lm$df.residual
# n
length(pressure)
# p
length(coefficients(Lubricant.lm))

# TS (overall)
anova(Lubricant.lm)
anova(Lubricant.lm)$F[1]
225.072/1.881

# CV (overall)
qf(0.95,1,length(viscos)-length(Lubricant.lm$coefficients))

# p-value
anova(Lubricant.lm)
1-pf(119.64,1,length(viscos)-length(Lubricant.lm$coefficients))


# 2. Use SUMMARY table (individual hypothesis for B1)
summary(Lubricant.lm)$coefficient
summary(Lubricant.lm)$coefficients[2,3]


# 3. Compare
summary(Lubricant.lm)$coefficients
anova(Lubricant.lm)

10.94^2
summary(Lubricant.lm)$coefficients[2,3] ^ 2
anova(Lubricant.lm)$F[1]

# Same p-values

# Challenge Syy=?
anova(Lubricant.lm)
225.07+95.94
sum((viscos - mean(viscos))^2)

# ==========================================================================================================
  
#### Q1 (e)
  
# Aassumptions for errors:
# (residuals -> errors)
# (1) Normally distributed
# (2) Constant variance
# (3) Independence
# (4) Linearity

# To check those assumptions:

# Residuals (ei=Yi-Yhat) versus fitted
plot(fitted(Lubricant.lm),residuals(Lubricant.lm), xlab="Fitted Values",ylab="Residuals",main="Fitted versus Residuals for Regression of Viscosity on Pressure")

# ==========================================================================================================

#### Q1 (f)

Lubricant

# 1. the number of observations for tempC at each level
table(tempC)                   # divide observations into different tempC level (tabulation)
tempCs <- unique(tempC)
tempCs

tempCs[1]
tempCs[2]
tempCs[3]
tempCs[4]

# 2. First divide the data into 4 separate temperature groups (1,2,3,4), corresponding to the 4 levels of tempC:
press1 <- pressure[tempC==tempCs[1]]
viscos1 <- viscos[tempC==tempCs[1]]

press2 <- pressure[tempC==tempCs[2]]
viscos2 <- viscos[tempC==tempCs[2]]

press3 <- pressure[tempC==tempCs[3]]
viscos3 <- viscos[tempC==tempCs[3]]

press4 <- pressure[tempC==tempCs[4]]
viscos4 <- viscos[tempC==tempCs[4]]

# 3. Now to create the plot, step by step for each of the four temperature groups:
plot(pressure, viscos, type="n", xlab="Pressure", ylab="Viscosity", main="Lubricant data")
points(press1, viscos1, pch="0")
points(press2, viscos2, pch="2")
points(press3, viscos3, pch="3")
points(press4, viscos4, pch="9")

# 4. Now fit 4 separate simple linear regression models:
tempC_l.lm <- lm(viscos1 ~ press1)
summary(tempC_l.lm)$coefficients

tempC_2.lm <- lm(viscos2 ~ press2)
summary(tempC_2.lm)$coefficients

tempC_3.lm <- lm(viscos3 ~ press3)
summary(tempC_3.lm)$coefficients

tempC_4.lm <- lm(viscos4 ~ press4)
summary(tempC_4.lm)$coefficients

# 5. And add these estimated regression lines to the plot with a suitable legend:
abline(tempC_l.lm$coef, lty=1)
abline(tempC_2.lm$coef, lty=2)
abline(tempC_3.lm$coef, lty=3)
abline(tempC_4.lm$coef, lty=4)
legend(5500, 7, paste(tempCs,"deg C"), pch=c("0","2","3","9"), lty=1:4,
       title="Temperature")

# 6. From the plot, it is obvious that viscosity depends on both pressure and temperature with distinctly different slopes for the four different levels of temperature.

